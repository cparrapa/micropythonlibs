<script setup lang="ts">
import {computed, ref} from 'vue';
import useSerial from "./composables/useSerial.ts";
import useBluetooth from "./composables/useBluetooth.ts";
import Snippets from "./components/Snippets.vue";

const toast = useToast();

const {
  connected: connectedSerial,
  uploading: uploadingSerial,
  uploadProgress: uploadProgressSerial,
  connect: connectSerial,
  disconnect: disconnectSerial,
  saveFile: saveFileSerial,
  executeCode: executeCodeSerial,
  enterRawRepl: enterRawReplSerial,
  reset: resetSerial,
} = useSerial(onSerialConnected);

const {
  connected: connectedBluetooth,
  uploading: uploadingBluetooth,
  uploadProgress: uploadProgressBluetooth,
  connect: connectBluetooth,
  disconnect: disconnectBluetooth,
  sendCode: executeCodeBluetooth,
  reset: resetBluetooth,
  connecting: connectingBluetooth,
  connectingProgress: connectingProgressBluetooth,
} = useBluetooth(onBluetoothConnected)

const uploading = computed(() => {
  if(connectedBluetooth.value){
    return uploadingBluetooth.value
  } else if(connectedSerial.value){
    return uploadingSerial.value
  } else {
    return false
  }
})

const uploadProgress = computed(() => {
  if(connectedBluetooth.value){
    return uploadProgressBluetooth.value
  } else if(connectedSerial.value){
    return uploadProgressSerial.value
  } else {
    return 0
  }
})

const remoteControlPrepared = ref(false);

function onSerialConnected(){
  remoteControlPrepared.value = false;
  resetBluetooth()
}

function onBluetoothConnected(){
  remoteControlPrepared.value = false;
  resetSerial()
}


async function executeCode(code: string, remoteControl: boolean){
  if(connectedSerial.value){
    // Used for block section
    if(!remoteControl){
      remoteControlPrepared.value = false;
      await enterRawReplSerial()
      // stop_flag is for loops
      await executeCodeSerial(`stop_flag = lambda: False\r\n${code}`);
      return
    }

    // Remote control has to import rc command, keep the Raw Repl session open
    // And transforms keys into function calls, the same function remote_control is called in main.py when connected over bluetooth
    if(!remoteControlPrepared.value){
      await enterRawReplSerial();
      await executeCodeSerial('import rc');
      remoteControlPrepared.value = true;
    }

    // The same function is called from main.py when connecting over bluetooth
    await executeCodeSerial(`rc.remote_control("${code}")`);
  } else if(connectedBluetooth.value) {
    // Used for block section
    if(!remoteControl){
      await executeCodeBluetooth(`${code}\n~`)
      return
    }

    // The @ character is checked in main.py for remote control keys
    await executeCodeBluetooth(`@${code}`)
  } else {
    toast.add({
      color: 'error',
      title: 'Device not connected'
    })
  }
}


const tabItems = [
  {
    label: 'Flasher',
    slot: 'flasher'
  },
  {
    label: 'Remote control',
    slot: 'remote-control'
  },
  {
    label: 'Blocks',
    slot: 'blocks'
  },
  {
    label: 'Firmware',
    slot: 'firmware'
  },
  {
    label: 'Code snippets',
    slot: 'snippets'
  }
]

</script>

<template>
<UApp>
  <div>
    <div class="px-2 py-1 border-b border-b-slate-500">
        <span class="text-lg font-semibold">KoalOtto Flasher</span>
    </div>
    <div class="px-2 mt-4">
      <div class="flex gap-2 items-center">
        <div class="border border-slate-500 p-2 rounded-md">
          <span class="text-sm font-medium uppercase">
            <span
              v-if="connectedSerial"
              class="text-green-500"
            >
              Serial Connected
            </span>
            <span
              v-else
              class="text-red-500"
            >
              Serial Disconnected
            </span>
          </span>
          <div class="flex gap-2 mt-2">
            <UButton
              label="Connect Serial"
              size="sm"
              :disabled="connectedSerial"
              @click="connectSerial"
            />
            <UButton
              color="error"
              label="Disconnect Serial"
              size="sm"
              :disabled="!connectedSerial"
              @click="disconnectSerial"
            />
          </div>
        </div>
        <div class="border border-slate-500 p-2 rounded-md">
          <span class="text-sm font-medium uppercase">
              <span
                  v-if="connectedBluetooth"
                  class="text-green-500"
              >
                Bluetooth Connected
              </span>
              <span
                  v-else
                  class="text-red-500"
              >
                Bluetooth Disconnected
              </span>
            </span>
          <div class="flex gap-2 mt-2">
            <UButton
                label="Connect Bluetooth"
                size="sm"
                :disabled="connectedBluetooth"
                @click="connectBluetooth"
            />
            <UButton
                color="error"
                label="Disconnect Bluetooth"
                size="sm"
                :disabled="!connectedBluetooth"
                @click="disconnectBluetooth"
            />
          </div>
          <UProgress
            v-if="connectingBluetooth"
            status
            :model-value="connectingProgressBluetooth"
            :max="100"
          />
          <span
            v-if="connectingBluetooth"
          >
            If it gets stuck at 50%, that means that Otto is restarting. Usually takes around 5 seconds in total
          </span>
        </div>
      </div>
      <div class="my-2">
        <span class="text-gray-300">
          When there is usercode.py, it takes some time to get running (3-4s), so be patient <br/>
          <strong>Code flasher - </strong> Here you can save any text content into any filename on Otto. Works only through <strong>Serial</strong> port<br/>
          <strong>Remote control - </strong> Here you can send predefined commands over <strong>Bluetooth and Serial</strong>. There is a slight delay over Serial<br/>
          <strong>Blocks - </strong> Code from Blocks gets executed in native mode, Raw Repl mode when Serial, or through exec() over bluetooth <br/>
          <strong>Snippets - </strong> Important files are main.py, rc.py, usercode.py and blocks_example.py
        </span>
      </div>
      <UTabs
        class="mt-4"
        :items="tabItems"
      >
        <template #flasher>
          <CodeFlasher
            :uploading="uploading"
            :progress="uploadProgress"
            :disabled="!connectedSerial"
            @upload="saveFileSerial($event.code, $event.fileName, $event.onComplete, $event.firstOta)"
            @execute="executeCode($event, false)"
          />
        </template>
        <template #remote-control>
          <RemoteControl
            :disabled="!connectedSerial && !connectedBluetooth"
            @execute="executeCode($event, true)"
          />
        </template>
        <template #firmware>
          <Firmware
            :disabled="!connectedSerial && !connectedBluetooth"
            @execute="executeCode($event, false)"
          />
        </template>
        <template #blocks>
          <Blocks
            :disabled="!connectedSerial && !connectedBluetooth"
            :uploading="uploading"
            :progress="uploadProgress"
            @execute="executeCode($event, false)"
          />
        </template>
        <template #snippets>
          <Snippets/>
        </template>
      </UTabs>
    </div>
  </div>
</UApp>
</template>
