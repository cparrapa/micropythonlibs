<script setup lang="ts">

defineProps<{
  disabled: boolean;
}>();

const emit = defineEmits<{
  execute: [string]
}>();

const actions: {label: string, items: {label: string, code: string}[]}[] = [
  {
    label: 'Movement',
    items: [
      {
        label: 'Forward',
        code: 'fwd'
      },
      {
        label: 'Backward',
        code: 'bwd'
      },
      {
        label: 'Left',
        code: 'left'
      },
      {
        label: 'Right',
        code: 'right'
      }
    ]
  },
  {
    label: 'Sound',
    items: [
      {
        label: 'Do',
        code: 'ndo'
      },
      {
        label: 'Le',
        code: 'nre'
      },
      {
        label: 'Mi',
        code: 'nmi'
      },
      {
        label: 'Fa',
        code: 'nfa'
      },
      {
        label: 'Sol',
        code: 'nsol'
      },
      {
        label: 'La',
        code: 'nla'
      },
      {
        label: 'Si',
        code: 'nsi'
      },
      {
        label: 'Edo',
        code: 'nedo'
      }
    ]
  },
  {
    label: 'Utility',
    items: [
      {
        label: 'Delete usercode.py',
        code: 'rst_user'
      }
    ]
  }
]


</script>

<template>
<div>
  <span class="text-sm text-gray-400">
    Here you can experiment with predefined commands in rc.py<br/>
    When using Serial connection, the codes are transformed into rc.remote_control(KEY) and executed, import rc is executed when starting RAW REPL session<br/>
    When using Bluetooth, keys are prepended with @ and sent to Otto where if-else chain takes care of the right command<br/>
    Keys are kept as short as possible to reduce bytes sent over bluetooth<br/>
    I have also managed to get bluetooth working on linux by tweaking settings in the main.py advertiser setup <br/>
    <strong class="uppercase text-gray-100">It might take a few seconds for the first command to go through over serial, don't loose hope ;)</strong>
  </span>

  <div
    class="flex flex-col gap-2 mt-4"
  >
    <div
      v-for="section in actions"
    >
      <span class="font-semibold">{{section.label}}</span>
      <div class="flex gap-1">
        <UButton
          v-for="action in section.items"
          size="xs"
          :disabled="disabled"
          :label="`${action.label} - ${action.code}`"
          @click="emit('execute', action.code)"
        />
      </div>
    </div>
  </div>
</div>
</template>
