<script setup lang="ts">
import {computed, ref} from "vue"

defineProps<{
  disabled: boolean;
}>();

const firmwareUrl = ref("https://www.micropython.org/resources/firmware/ESP32_GENERIC-OTA-20241129-v1.24.1.app-bin")
// const otaLibraryUrl = ref("https://raw.githubusercontent.com/glenn20/micropython-esp32-ota/main/mip/ota")
const wifiSsid = ref("hotspot")
const wifiPassword = ref("hotspot123")


const code = computed(() => {
  return `
update_firmware("${wifiSsid.value}", "${wifiPassword.value}", "${firmwareUrl.value}")`
})

const emit = defineEmits<{
  execute: [string]
}>();


</script>

<template>
<div class="flex flex-col gap-2 items-start">
  <UFormField label="Firmware URL" class="w-full">
    <UInput v-model:model-value="firmwareUrl" class="w-full"/>
  </UFormField>
<!--  <UFormField label="OTA library URL" class="w-full">-->
<!--    <UInput v-model:model-value="otaLibraryUrl" class="w-full"/>-->
<!--  </UFormField>-->
  <UFormField label="Wifi SSID" class="w-full">
    <UInput v-model:model-value="wifiSsid" class="w-full"/>
  </UFormField>
  <UFormField label="Wifi password" class="w-full">
    <UInput v-model:model-value="wifiPassword" class="w-full"/>
  </UFormField>
  <UButton :disabled="disabled" @click="emit('execute', code)">Run</UButton>
  <pre>
    {{code}}
  </pre>
</div>
</template>
