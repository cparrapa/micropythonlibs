<script setup lang="ts">
import {z} from "zod";
import {ref} from "vue";
import type {FormSubmitEvent} from "@nuxt/ui";
import {loadFiles} from "../utils/file.ts";

defineProps<{
  disabled: boolean;
  progress: number;
  uploading: boolean;
}>();

const emit = defineEmits<{
  upload: [{fileName: string, code: string, onComplete?: () => void, firstOta?: boolean}];
  execute: [string]
}>();

const uploadCodeSchema = z.object({
  fileName: z.string().min(1, "Has to be at least 2 characters").endsWith('.py', 'Has to be a .py file'),
  code: z.string()
})

export type UploadCodeDto = z.output<typeof uploadCodeSchema>

const uploadCodeState = ref<UploadCodeDto>({
  fileName: '',
  code: ''
})

function formSubmit(event: FormSubmitEvent<UploadCodeDto>){
  emit('upload', {
    fileName: event.data.fileName,
    code: event.data.code
  })
}

const libraryFilenames = [
  "adxl345.py",
  "main.py",
  "ottobuzzer.py",
  "ottomotor.py",
  "ottoneopixel.py",
  "ottooled.py",
  "ottosensors.py",
  "ottowalkroll.py",
  "rc.py",
  "ssd1306.py",
  "firmware_update.py",
  "wifi_manager.py"
]

// const otaLibraryUrl = "https://raw.githubusercontent.com/glenn20/micropython-esp32-ota/main/mip/ota"
const otaLibraryUrl = "http://localhost:8080/ota"

const otaLibraryFilenames = [
  "/update.py",
  "/rollback.py",
  "/status.py",
  "/blockdev_writer.py",
  "/__init__.py",
]

const uploadingLibraries = ref(false);
const uploadingFileTotalCount = ref(0);
const uploadingFileCount = ref(0);

async function uploadOtaLibraries(){
  uploadingLibraries.value = true;
  uploadingFileTotalCount.value = otaLibraryFilenames.length

  let firstOta = true;
  for(const file of otaLibraryFilenames){
    const response = await fetch(`${otaLibraryUrl}${file}`)
    const code = await response.text()
    uploadingFileCount.value++;

    await new Promise<void>((resolve) => {
      emit('upload', {
        fileName: `lib/ota${file}`,
        code,
        onComplete: resolve,
        firstOta
      })
    })

    firstOta = false
  }

  uploadingLibraries.value = false;
  uploadingFileCount.value = 0
}

async function uploadLibraries(){
  uploadingLibraries.value = true;
  uploadingFileTotalCount.value = libraryFilenames.length

  const files = await loadFiles()
  const filteredFiles = files.filter(f => libraryFilenames.includes(f.filename))

  for(const file of filteredFiles){
    uploadingFileCount.value++;
    await new Promise<void>((resolve) => {
      emit('upload', {
        fileName: file.filename,
        code: file.code,
        onComplete: resolve
      })
    })
  }
}

async function deleteAllFiles(){
  const deleterCode = await (await fetch('/code/file_deleter.py')).text()
  emit('execute', deleterCode)
}

</script>

<template>
  <span class="text-sm text-gray-400">
    Here you can "flash/upload" python code to specified filename for testing purposes <br/>
    <strong>Delete all files</strong>  - uses file_deleter.py in the Snippets section to delete all files on Otto <br/>
    <strong>Upload all libraries</strong> - takes only the necessary libraries and uploads them to Otto <br/>
    {{libraryFilenames.join(', ')}}
  </span>
  <div class="flex gap-2 my-2">
    <UButton
      label="Delete all files on Otto"
      color="error"
      :disabled="uploadingLibraries || disabled"
      @click="deleteAllFiles"
    />
    <UButton
      label="Upload all required libraries"
      :disabled="uploadingLibraries || disabled"
      @click="uploadLibraries"
    />
    <UButton
      label="Upload OTA libraries"
      :disabled="uploadingLibraries || disabled"
      @click="uploadOtaLibraries"
    />
  </div>
  <UForm
      class="space-y-4 mt-2"
      :disabled="disabled || uploading"
      :schema="uploadCodeSchema"
      :state="uploadCodeState"
      @submit="formSubmit($event)"
  >
    <UFormField name="fileName" label="File Name">
      <UInput
          v-model="uploadCodeState.fileName"
          placeholder="main.py"
      />
    </UFormField>
    <UFormField name="code" label="Code">
      <UTextarea
          v-model="uploadCodeState.code"
          :rows="20"
          class="w-full"
      />
    </UFormField>
    <UButton
      type="submit"
      label="Upload code"
      :disabled="disabled || uploading || uploadingLibraries"
    />
    <div class="mt-2">
      <span
          v-if="uploadingLibraries"
          class="text-lg"
      >
        Files uploaded:
        {{uploadingFileCount}}/{{uploadingFileTotalCount}}
      </span>
      <UProgress
        v-if="uploading"
        status
        :modelValue="progress"
        :max="100"
      />
    </div>
  </UForm>
</template>
