# KoalOtto Flasher
## How to get up and running
1. Connect Otto over serial
2. From the `Snippets` section, flash `main.py` and `rc.py` files
3. Restart Otto
4. Connect Otto over serial again and you can experiment with few example commands in the remote control session or send code from hprobots platform in the Blocks section
5. For Bluetooth, turn Otto on and off and try to connect via bluetooth and experiment with remote control and blocks section
6. Code flasher is disabled for bluetooth for now

## How to get the App up and running
1. Run `npm install`
2. Run `npm run dev` and app will be accessible at `http://localhost:5173`
3. Connection methods are in composables `src/composables/useBluetooth.ts` and `src/composables/useSerial.ts`

## How to prepare Otto for OTA updates
1. Install esptool.py [MacOS](https://formulae.brew.sh/formula/esptool)
2. Connect Otto to computer - obviously
3. Erase existing firmware `esptool.py erase_flash`
4. Download latest OTA firmware (.bin) from [micropython.org](https://micropython.org/download/ESP32_GENERIC/). The latest now is [v1.25.0.bin](https://micropython.org/resources/firmware/ESP32_GENERIC-OTA-20250415-v1.25.0.bin)
5. Run `esptool.py --baud 460800 write_flash 0x1000 PATH_TO_FIRMWARE.bin`
