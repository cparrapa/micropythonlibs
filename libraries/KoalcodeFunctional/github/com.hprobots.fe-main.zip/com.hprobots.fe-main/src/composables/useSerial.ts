import {computed, ref, onUnmounted} from "vue";
import {wait, isIncompleteEscapeSequence} from '../utils'
import {asciiKeyMap, type AsciiKeyValue, keys} from "../data/repl.ts";

export default function useSerial(onConnectedCallback: () => void){
	const toast = useToast();

	const port = ref<SerialPort | null>();
	const writer = ref<WritableStreamDefaultWriter<Uint8Array> | null>(null);
	const reader = ref<ReadableStreamDefaultReader<Uint8Array> | null>(null);
	const connected = computed(() => !!port.value);
	const readingActive = ref(false);

	const uploading = ref(false);
	const uploadProgress = ref<number>(0);

	function reset(){
		port.value = null;
		writer.value = null;
		reader.value = null;
		readingActive.value = false;
		uploading.value = false;
		uploadProgress.value = 0;
	}

	async function startReading() {
		if (!port.value || !port.value.readable) {
			console.error("Cannot start reading: port not available or not readable");
			return;
		}

		try {
			reader.value = port.value.readable.getReader();
			readingActive.value = true;

			// Start the reading loop
			readLoop();
		} catch (err) {
			console.error("Error setting up serial reader:", err);
			readingActive.value = false;
		}
	}

	async function readLoop() {
		if (!reader.value || !readingActive.value) return;

		try {
			while (readingActive.value) {
				const { value, done } = await reader.value.read();

				if (done) {
					// The stream was closed
					break;
				}

				if (value) {
					// Convert the Uint8Array to a string and log it
					const textDecoder = new TextDecoder();
					const text = textDecoder.decode(value);
					console.log("ESP32 output:", text);
				}
			}
		} catch (err) {
			console.error("Error reading from serial port:", err);
		} finally {
			if (reader.value) {
				reader.value.releaseLock();
				reader.value = null;
			}
			readingActive.value = false;
		}
	}

	async function stopReading() {
		readingActive.value = false;
		if (reader.value) {
			try {
				reader.value.releaseLock();
			} catch (err) {
				console.error("Error releasing reader lock:", err);
			}
			reader.value = null;
		}
	}

	async function connect(){
		if(!navigator.serial){
			toast.add({color: 'error', title: "Your browser does not support the Web Serial API", description: 'Try Chrome ;)'})
			return
		}

		try {
			port.value = await navigator.serial.requestPort();
			await port.value.open({baudRate: 115200})

			if(!port.value || !port.value.writable || !port.value.readable){
				toast.add({
					color: 'error',
					title: 'Cannot connect to Otto over serial',
					description: "port not opened, or something else is wrong"
				})
				return
			}

			writer.value = port.value.writable.getWriter();

			await enterRawRepl();
			await exitRawRepl();

			// Start reading from the serial port
			await startReading();

			onConnectedCallback();
		} catch(err){
			console.error(err);
			// @ts-ignore
			toast.add({color: 'error', title: 'Cannot connect to Otto over serial', description: err.message})
		}
	}

	async function writeSerial(keys: AsciiKeyValue[]) {
		if(!writer.value){
			toast.add({
				color: 'error',
				title: 'Writer not found'
			})
			return
		}

		for(const key of keys){
			const data = new Uint8Array([asciiKeyMap[key]])

			await writer.value.write(data);
			await wait(10);
		}
	}

	// Enter RAW REPL mode through series of keyboard shortcuts
	async function enterRawRepl() {
		const commands = [
			...keys.ctrlC, // Stops all the running code
			...keys.ctrlA, // Enter RAW REPL mode
			...keys.ctrlD, // Soft reset
			...keys.ctrlC // Clear running code
		]

		await writeSerial(commands)
	}

	async function exitRawRepl() {
		await writeSerial(keys.ctrlB)
	}

	async function disconnect() {
		if (!port.value) {
			toast.add({
				color: 'error',
				title: "Device already disconnected"
			})
			return
		}

		// Stop reading before disconnecting
		await stopReading();

		await writeSerial(keys.ctrlD);

		if (writer.value){
			writer.value.releaseLock();
		}

		await port.value.close();

		reset();
	}

	async function executeCode(command: string) {
		if(!writer.value){
			toast.add({
				color: 'error',
				title: 'Writer not found'
			})
			return
		}

		const enc = new TextEncoder();
		const command_bytes = enc.encode(command);
		console.log(`Command: "${command}", length: ${command_bytes.length}`)

		for (let i = 0, s = command_bytes.length; i < s; i += 32) {
			const dataToSend = command_bytes.slice( i, Math.min(i + 32, command_bytes.length) );
			await writer.value.write(dataToSend);
			await wait(50);
		}

		await writeSerial(keys.ctrlD);
	}

	async function saveFile(pythonCode: string, filename: string, onComplete?: () => void, firstOta?: boolean) {
		uploadProgress.value = 0;
		uploading.value = true;

		await enterRawRepl();
		if(firstOta){
			const otaInitCode = `
import os
import gc

try:
   files = os.listdir('lib/ota')
   for file in files:
	   try:
		   os.remove(f'lib/ota/{file}')
	   except OSError:
		   pass
   os.rmdir('lib/ota')
except OSError:
   pass

try:
   os.mkdir('lib')
except OSError:
   pass
   
try:
   os.mkdir('lib/ota')
except OSError:
	pass`
			await executeCode(otaInitCode)
		}

		await executeCode(`f = open('${filename}', 'wb')`);
		const QUOTED_NEWLINE_MARKER = "%^";
		pythonCode = pythonCode.replace(/'\\n'/g, QUOTED_NEWLINE_MARKER);
		pythonCode = pythonCode.replace(/(\r\n|\n|\r)/gm, "£").replace(/"/g, '\\"');
		pythonCode = pythonCode.replace(new RegExp(QUOTED_NEWLINE_MARKER, 'g'), "'\\n'");

		const n = 256;
		let position = 0;

		while (position < pythonCode.length) {
			let endPosition = Math.min(position + n, pythonCode.length);
			let subcommand = pythonCode.slice(position, endPosition);

			while (endPosition < pythonCode.length && isIncompleteEscapeSequence(subcommand)) {
				endPosition++;
				subcommand = pythonCode.slice(position, endPosition);
			}

			subcommand = subcommand.replace(/£/g, "\\n");

			await executeCode(`f.write("${subcommand}")`);

			uploadProgress.value = Math.floor(Math.min((endPosition / pythonCode.length) * 100, 100));
			position = endPosition;

			await wait(200);
		}

		await executeCode("f.close()");
		await exitRawRepl();

		uploading.value = false;
		uploadProgress.value = 0;

		onComplete ? onComplete() : undefined
	}

	// Clean up when the component is unmounted
	onUnmounted(() => {
		if (connected.value) {
			disconnect();
		}
	});

	return {
		connected,
		uploading,
		uploadProgress,
		connect,
		disconnect,
		saveFile,
		executeCode,
		enterRawRepl,
		exitRawRepl,
		reset,
	}
}
