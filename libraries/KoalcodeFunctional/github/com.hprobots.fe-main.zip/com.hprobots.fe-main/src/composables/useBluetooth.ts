import {ref} from 'vue';
import {wait} from '../utils'

export default function useBluetooth(onConnectedCallback: () => void, onMessageCallback?: (message: string) => void){
    const toast = useToast();
    const connectedDevice = ref<BluetoothDevice | null>(null)
    const connected = ref(false);
    const bluetoothCharacteristic = ref<BluetoothRemoteGATTCharacteristic | null>(null);

    const uploading = ref(false);
    const uploadProgress = ref<number>(0);

    const connecting = ref(false);
    const connectingProgress = ref(0);

    // Add a new ref to store received messages
    const receivedMessages = ref<string[]>([]);

    function reset(){
        connectedDevice.value = null;
        connected.value = false;
        bluetoothCharacteristic.value = null;
        receivedMessages.value = [];
    }

    async function connect() {
        if(!navigator.bluetooth){
            toast.add({
                color: 'error',
                title: 'Your browser does not support Web Bluetooth',
                description: 'Try Chrome ;)'
            })
            return
        }

        try {
            // First we grab the device
            connectedDevice.value = await navigator.bluetooth.requestDevice({
                acceptAllDevices: true,
                optionalServices: ["6e400001-b5a3-f393-e0a9-e50e24dcca9e"]
            })

            connecting.value = true;
            connectingProgress.value = 0;

            const tryToConnect = async () => {
                if(!connectedDevice.value){
                    throw new Error("Device not connected from custom error")
                }

                const bluetoothRemoteGATTServer = await connectedDevice.value.gatt!.connect()
                connectingProgress.value += 10;
                const service = await bluetoothRemoteGATTServer.getPrimaryService("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
                connectingProgress.value += 10;

                bluetoothCharacteristic.value = await service.getCharacteristic("6e400003-b5a3-f393-e0a9-e50e24dcca9e")
                connectingProgress.value += 10;

                await startNotifications()
                connectingProgress.value += 10;
            }

            await tryToConnect();


            // If user code is running, the first sent command will stop it and reset the device
            // So this code is bound to fail
            try {
                await bluetoothCharacteristic.value!.writeValue(new TextEncoder().encode(""));
                // If this doesn't crash, that means that otto was ready for connection
                connectingProgress.value += 60;
            } catch(error){
                // After the user code is stopped, the ESP resets, we have to connect again, but we already have the device, just not the GATT server
                connectingProgress.value += 10;
                await tryToConnect()
                connectingProgress.value += 10;
            }

            connecting.value = false;
            connected.value = true;
            onConnectedCallback()
        } catch(error){
            console.error(error)
            toast.add({
                color: 'error',
                title: 'Device is disconnected',
                description: 'Refresh the page and try again, that should do the job'
            })
        }
    }

    async function startNotifications() {
        if(!bluetoothCharacteristic.value){
            throw new Error('Characteristic not found');
        }

        await bluetoothCharacteristic.value.startNotifications()
        bluetoothCharacteristic.value!.addEventListener('characteristicvaluechanged', onValueChanged);
    }

    // Buffer to collect message fragments
    let messageBuffer = "";

    function onValueChanged(event: Event) {
        // Cast the event target to the correct type
        const target = event.target as BluetoothRemoteGATTCharacteristic;
        if (!target.value) return;

        // Decode the received data
        const decoder = new TextDecoder('utf-8');
        const chunk = decoder.decode(target.value);
        console.log(chunk)

        // Append to our buffer
        messageBuffer += chunk;

        // Check if we have complete lines to process
        const lines = messageBuffer.split('\n');

        // If the message doesn't end with a newline, keep the last part in the buffer
        if (!messageBuffer.endsWith('\n')) {
            messageBuffer = lines.pop() || "";
        } else {
            messageBuffer = "";
        }

        // Process complete lines
        for (const line of lines) {
            if (line.trim()) {  // Only process non-empty lines
                // Add to our messages array
                receivedMessages.value.push(line);

                // Log to console with a prefix for clarity
                console.log(`[ESP32]: ${line}`);

                // Call the optional callback if provided
                if (onMessageCallback) {
                    onMessageCallback(line);
                }
            }
        }
    }

    function disconnect() {
        if(!connectedDevice.value){
            toast.add({
                color: 'error',
                title: 'No device connected'
            })
            return;
        }

        connectedDevice.value.gatt!.disconnect();
        bluetoothCharacteristic.value = null;
        connected.value = false;
    }

    async function sendCode(command: string): Promise<void> {
        if(!bluetoothCharacteristic.value){
            toast.add({
                color: 'error',
                title: 'Bluetooth characteristic not found'
            })
            return
        }

        uploading.value = true;
        uploadProgress.value = 0;

        let encoder = new TextEncoder();
        let command_bytes = encoder.encode(command);

        // Just for info and byte size optimization
        console.log(`Command: ${command}, length: ${command_bytes.length} bytes`);

        for (let i = 0; i < command_bytes.length; i += 16) {
            let dataToSend = command_bytes.slice(i, Math.min(i + 16, command_bytes.length));

            uploadProgress.value = Math.floor(Math.min(((i + 16) / command_bytes.length) * 100, 100));

            await bluetoothCharacteristic.value.writeValue(dataToSend);
            await wait(10);
        }

        uploading.value = false;
        uploadProgress.value = 0;
    }

    // Helper function to clear the message history if needed
    function clearMessages() {
        receivedMessages.value = [];
    }

    return {
        connected,
        connectedDevice,
        uploading,
        uploadProgress,
        connecting,
        connectingProgress,
        receivedMessages, // Expose the messages array
        reset,
        connect,
        sendCode,
        disconnect,
        clearMessages, // Expose method to clear messages
    }
}
