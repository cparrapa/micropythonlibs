import "./assets/main.css";

import { createApp } from 'vue'
import App from './App.vue'
import uiPlugin from "@nuxt/ui/vue-plugin";

import 'highlight.js/styles/stackoverflow-light.css'
import hljs from 'highlight.js/lib/core';
import python from 'highlight.js/lib/languages/python';
import hljsVuePlugin from "@highlightjs/vue-plugin";

hljs.registerLanguage('python', python);

const app = createApp(App);

app.use(uiPlugin);

app.use(hljsVuePlugin)
app.mount('#app')
