<script setup lang="ts">
import {computed, ref} from 'vue';
import hljsVuePlugin from "@highlightjs/vue-plugin";
import {useClipboard} from "@vueuse/core";
import {loadFiles} from '../utils/file'
const hightlighjs = hljsVuePlugin.component

const toast = useToast();
const {copy} = useClipboard()

const files = ref<{filename: string, code: string}[]>([]);
const items = computed(() => {
  return files.value.map(file => ({
    label: file.filename,
    code: file.code
  }))
})

loadFiles().then(data => {
  files.value = data;
})
</script>

<template>
  <div>
    <UAccordion :items="items">
      <template #content="{item}">
        <hightlighjs language="python" :code="item.code"/>
      </template>
      <template #leading="{item}">
        <UButton
          label="Copy code"
          variant="ghost"
          size="xs"
          @click.stop="
            copy(item.code);
            toast.add({
              color: 'success',
              title: 'Code copied into clipboard!'
            })
          "
        />
      </template>
    </UAccordion>
  </div>
</template>
<style>
.hljs {
  background: none !important;
  color: white !important;
}
</style>
