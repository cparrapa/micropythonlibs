<script setup lang="ts">
import {computed, ref} from "vue"

defineProps<{
  disabled: boolean;
}>();

const librariesUrl = ref("https://koalotto.vercel.app/code/")
const wifiSsid = ref("hotspot")
const wifiPassword = ref("hotspot123")
const name = ref("Otto")


const code = computed(() => {
  return `
update_firmware("${wifiSsid.value}", "${wifiPassword.value}", "${librariesUrl.value}")`
})

const nameCode = computed(() => {
  return `set_ble_name("${name.value}")`
})

const emit = defineEmits<{
  execute: [string]
}>();

</script>

<template>
<div class="flex flex-col gap-2 items-start">
  <UFormField label="Libraries URL" class="w-full">
    <UInput v-model:model-value="librariesUrl" class="w-full"/>
  </UFormField>
  <UFormField label="Wifi SSID" class="w-full">
    <UInput v-model:model-value="wifiSsid" class="w-full"/>
  </UFormField>
  <UFormField label="Wifi password" class="w-full">
    <UInput v-model:model-value="wifiPassword" class="w-full"/>
  </UFormField>
  <UButton :disabled="disabled" @click="emit('execute', code)">Run</UButton>
  <pre>
    {{code}}
  </pre>
  <div class="my-4"></div>
  <UFormField label="Set Otto name" class="w-full">
    <UInput v-model:model-value="name" class="w-full"/>
  </UFormField>
  <UButton label="Set otto name" :disabled="disabled" @click="emit('execute', nameCode)"/>
  <pre>
    {{nameCode}}
  </pre>
</div>
</template>
