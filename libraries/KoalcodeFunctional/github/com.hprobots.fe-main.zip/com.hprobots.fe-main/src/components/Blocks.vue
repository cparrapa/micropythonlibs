<script setup lang="ts">
import {ref} from 'vue'

defineProps<{
  disabled: boolean;
  progress: number;
  uploading: boolean;
}>();

const emit = defineEmits<{
  execute: [string]
}>();

const code = ref<string>("");
</script>

<template>
<div class="flex flex-col gap-2 items-start">
  <span class="text-sm text-gray-400">
    Here you can paste a code from the icon/word block section from hprobots<br/>
    It gets executed over the connected port
  </span>
  <UTextarea
    v-model="code"
    class="w-full"
    :rows="20"
    :disabled="disabled"
  />
  <UButton
    label="Execute"
    :disabled="disabled"
    @click="emit('execute', code)"
  />
  <UProgress
    v-if="uploading"
    status
    :modelValue="progress"
    :max="100"
  />
</div>
</template>
