<script setup lang="ts">

defineProps<{
  disabled: boolean;
}>();

const emit = defineEmits<{
  execute: [string]
}>();

const actions: {label: string, items: {label: string, code: string}[]}[] = [
  {
    label: 'Movement',
    items: [
      {
        label: 'Forward',
        code: 'Mf'
      },
      {
        label: 'Backward',
        code: 'Mb'
      },
      {
        label: 'Left',
        code: 'Ml'
      },
      {
        label: 'Right',
        code: 'Mr'
      },
      {
        label: 'Forward',
        code: 'Mfn'
      },
      {
        label: 'Backward',
        code: 'Mbn'
      },
      {
        label: 'Left',
        code: 'Mln'
      },
      {
        label: 'Right',
        code: 'Mrn'
      },
      {
        label: 'Stop',
        code: 'MX'
      }
    ]
  },
  {
    label: 'Movement Joystick Degrees',
    items: (() => {
      const commands: {label: string, code: string}[] = [{label: 'Joystick stop', code: 'JX'}]
      for (let i = 0; i < 360; i += 30){
        commands.push({
          label: ``,
          code: `J${i}#5`
        })
        commands.push({
          label: ``,
          code: `J${i}#10`
        })
      }
      return commands
    })()
  },
  {
    label: 'Color ring',
    items: [
      {
        label: 'Turn on random',
        code: 'Cabcdefghijabc'
      },
      {
        label: 'Turn off',
        code: 'C!'
      },
      {
        label: 'Turn on',
        code: 'C*'
      },
      {
        label: 'Turn of one led RED',
        code: 'C#01FF0000'
      },
    ]
  },
  {
    label: 'Ultrasonic colors',
    items: [
      {
        label: 'Turn off',
        code: 'UC!'
      },
      {
        label: 'Turn on',
        code: 'UC*'
      },
      {
        label: 'Turn on',
        code: 'UCFFFFFFFF0000'
      },
    ]
  },
  {
    label: 'Movement settings',
    items: [
      {
        label: 'Slider values (left + right)',
        code: 'MSs100050'
      },
    ]
  },
  {
    label: 'Sound',
    items: [
      {
        label: 'Do',
        code: 'Ndo'
      },
      {
        label: 'Le',
        code: 'Nre'
      },
      {
        label: 'Mi',
        code: 'Nmi'
      },
      {
        label: 'Fa',
        code: 'Nfa'
      },
      {
        label: 'Sol',
        code: 'Nsol'
      },
      {
        label: 'La',
        code: 'Nla'
      },
      {
        label: 'Si',
        code: 'Nsi'
      },
      {
        label: 'Edo',
        code: 'Nedo'
      }
    ]
  },
  {
    label: 'Utility',
    items: [
      {
        label: 'Delete usercode.py',
        code: 'Trusrc'
      },
      {
        label: 'Test sensors',
        code: 'test'
      }
    ]
  },
  {
    label: 'Sound emotes',
    items: ['connect', 'disconnect', 'button', 'mode1', 'mode2', 'mode3', 'surprise', 'jump', 'oh', 'oh2', 'cuddle', 'sleep', 'happy', 'superhappy', 'happyshort', 'sad', 'confused', 'fart1', 'fart2', 'fart3'].map((emote) => ({
      label: emote,
      code: `E${emote}`
    }))
  },
  {
    label: 'Dance moves',
    items: [
      {
        label: 'Dance',
        code: 'Wd'
      },
      {
        label: 'Moonwalk left',
        code: 'Wmwl'
      },
      {
        label: 'Moonwalk right',
        code: 'Wmwr'
      },
      {
        label: 'Crosing left',
        code: 'Wcl'
      },
      {
        label: 'Crosing right',
        code: 'Wcr'
      },
    ]
  },
  {
    label: 'Sensors',
    items: [
      {
        label: 'Start ultrasonic sensor',
        code: 'R0013'
      },
      {
        label: 'Stop ultrasonic sensor',
        code: 'R000'
      },
      {
        label: 'Start line sensors',
        code: 'R0113'
      },
      {
        label: 'Stop line sensors',
        code: 'R010'
      },
    ]
  }
]


</script>

<template>
<div>
  <span class="text-sm text-gray-400">
    Here you can experiment with predefined commands in rc.py<br/>
    When using Serial connection, the codes are transformed into rc.remote_control(KEY) and executed, import rc is executed when starting RAW REPL session<br/>
    When using Bluetooth, keys are prepended with @ and sent to Otto where if-else chain takes care of the right command<br/>
    Keys are kept as short as possible to reduce bytes sent over bluetooth<br/>
    I have also managed to get bluetooth working on linux by tweaking settings in the main.py advertiser setup <br/>
    <strong class="uppercase text-gray-100">It might take a few seconds for the first command to go through over serial, don't loose hope ;)</strong>
  </span>

  <div
    class="flex flex-col gap-2 mt-4"
  >
    <div
      v-for="section in actions"
    >
      <span class="font-semibold">{{section.label}}</span>
      <div class="flex gap-1">
        <UButton
          v-for="action in section.items"
          size="xs"
          :disabled="disabled"
          :label="`${action.label} - ${action.code}`"
          @click="emit('execute', action.code)"
        />
      </div>
    </div>
  </div>
</div>
</template>
