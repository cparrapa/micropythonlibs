export type AsciiKeyValue = '01' | '02' | '03' | '04';
export type AsciiKey = 'ctrlC' | 'ctrlA' | 'ctrlD' | 'ctrlB';

export const keys: {[k in AsciiKey]: AsciiKeyValue[]} = {
	ctrlA: ['01', '01', '01', '01', '01'], // Enter RAW REPL mode
	ctrlB: ['02'], // exit RAW REPL mode
	ctrlC: ['03', '03'], // Stops all running code
	ctrlD: ['04'], // soft reset
};


export const asciiKeyMap: {[k in AsciiKeyValue]: number} = {
	"01": 0x01,
	"02": 0x02,
	"03": 0x03,
	"04": 0x04
};
