/// <reference types="vite/client" />
/// <reference types="w3c-web-serial" />
/// <reference types="web-bluetooth" />
