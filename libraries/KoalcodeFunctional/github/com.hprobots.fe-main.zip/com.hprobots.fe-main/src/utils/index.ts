export function wait(ms: number): Promise<void>{
	return new Promise((resolve) => setTimeout(resolve, ms));
}

export function isIncompleteEscapeSequence(str: string) {
	let backslashCount = 0;
	let i = str.length - 1;
	while (i >= 0 && str[i] === '\\') {
		backslashCount++;
		i--;
	}
	return backslashCount % 2 === 1;
}
