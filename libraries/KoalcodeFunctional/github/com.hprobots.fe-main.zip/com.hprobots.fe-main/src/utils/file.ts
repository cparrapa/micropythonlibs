export async function loadFiles(): Promise<{filename: string, code: string}[]>{
	const rawFiles = import.meta.glob('/public/code/*.py', {query: '?raw', import: 'default'})

	const filenames = Object.keys(rawFiles).map(fileName => fileName.split('public')[1])

	return await Promise.all(filenames.map(async (filename) => {
		const code = await (await fetch(filename)).text()

		const filenameSplit = filename.split('/')

		return {
			filename: filenameSplit[filenameSplit.length - 1] as string,
			code
		}
	}));
}
